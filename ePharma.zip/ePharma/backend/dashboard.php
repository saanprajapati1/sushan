<!DOCTYPE html>
<html>
<head>
  <!-- Favicon -->
  <link rel="icon" href="images/favicon.png" type="image/png">
  <style type="text/css">
    .fas
    {   font-size: 100px; 
    }
    img{height: 150px;width: 150px;}
  </style>
</head>
<body>
  <?php include 'include/navigation.php' ?>
    <div class="container">
      <div class="jumbotron mt-5 ml-5" style="padding: 1rem 2rem;">
      <font size="6" class="text-monospace">Admin Panel</font>
    <div class="row text-center">
      <a href="admin_list.php" class="col-md-2"><img src="images/1.png"><br>List Admins</a>
      <a href="admin_add.php" class="col-md-2"><img src="images/2.png"><br>Add Admin</a>
      <a href="admin_list.php" class="col-md-2"><img src="images/3.jpg"><br>Update Admins</a>
      <a href="admin_list.php" class="col-md-2"><img src="images/4.png"><br>Delete Admins</a>
      <a href="drug_list.php" class="col-md-2"><img src="images/5.jpg"><br>List Drugs</a>
      <a href="drug_add.php" class="col-md-2"><img src="images/6.png"><br>Add Drugs</a>
    </div>
    <div class="row mt-4 text-center"> 
      <a href="drug_list.php" class="col-md-2"><img src="images/7.jpg"><br>Update Drugs</a>
      <a href="drug_list.php" class="col-md-2"><img src="images/8.jpg"><br>Delete Drugs</a>
      <a href="client_list.php" class="col-md-2"><img src="images/9.png"><br>List Clients</a>
      <a href="client_add.php" class="col-md-2"><img src="images/10.png"><br>Add Clients</a>
      <a href="client_list.php" class="col-md-2"><img src="images/11.png"><br>Update Clients</a>
      <a href="client_list.php" class="col-md-2"><img src="images/12.png"><br>Delete Clients</a>
    </div>
    <div class="row mt-4 text-center">
     <a href="../index.php" class="col-md-2"><img src="images/13.jpg"><br>Visit Frontend</a>
    </div>
  </div>
      <?php include 'include/footer.php' ?>
    </div>

</body>
</html>