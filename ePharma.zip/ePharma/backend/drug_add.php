<?php
if (isset($_POST['add_drug'])) {
	// echo "Nepal";exit();
	$name = $_POST['name'];
	$code = $_POST['code'];
	$description = $_POST['description'];
	$price = $_POST['price'];

			$sql = "INSERT INTO `drug` (`name`,`code`,`description`,`price`) VALUES ('$name','$code','$description','$price')";
		require_once("DBConnect.php");
		if (mysqli_query($conn, $sql)) {
		    // echo "New record created successfully.";
		    header('Location: drug_list.php');
		} else {
		    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
		}
?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php include 'include/navigation.php';?>
	<div class="container">
		<h1>Add Drug</h1>
		<form action="" method="POST" name="drug">
			<table class="table-sm mb-2">
				<tr>
					<td>Product Code : </td>
					<td><input type="text" name="code" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>Product Name : </td>
					<td><input type="text" name="name" class="form-control form-control-sm" required></td>
				</tr>
				<tr>
					<td>Description : </td>
					<td><textarea class="form-control form-control-sm"></textarea></td>
				</tr>
				<tr>
					<td>Price / piece : </td>
					<td><input type="number" name="price" class="form-control form-control-sm" min="5" required></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td class="text-center"><button type="submit" name="add_drug" class="btn btn-success btn-block">Add</button></td>
				</tr>
			</table>
		</form>
		<?php include 'include/footer.php';?>
	</div>
</body>
</html>