<?php
$code = @$_GET['code'];
if (!isset($code)) {
	header('Location: drug_list.php');
}
require_once('DBConnect.php');
$sql = "DELETE FROM `drug` WHERE code='$code';";

if (mysqli_query($conn, $sql)) {
    // echo "Record deleted successfully";
    header('Location: drug_list.php');
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}