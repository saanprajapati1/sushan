<?php
$code = @$_GET['code'];
if (!isset($code)) {
	header('Location: drug_list.php');
}
require_once("DBConnect.php");
$sql = "SELECT * FROM `drug` WHERE `code`='$code'";
$result = mysqli_query($conn, $sql);
$prev_data = mysqli_fetch_assoc($result);
if (isset($_POST['updater'])) {
	$name = $_POST['name'];
	$description = $_POST['description'];
	$price = $_POST['price'];
	$sql = "UPDATE `drug` SET `name`='$name',`price`='$price',`description`='$description' WHERE `code`='$code';";
require_once("DBConnect.php");
if (mysqli_query($conn, $sql)) {
    // echo "Record updated successfully";
    header('Location: drug_list.php');
} else {
    echo "Error updating record: " . mysqli_error($conn);
}
mysqli_close($conn);
}
?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php include 'include/navigation.php';?>
<div class="container">
<h1>Update drug #EP<?= $prev_data['code'];?></h1>
<form action="" method="POST" name="drug">
<table class="table-responsive-sm">
	<tr>
		<td>Product Code : </td>
		<td><input type="text" name="code" class="form-control form-control-sm" required value="<?= $prev_data['code'];?>" disabled></td>
	</tr>
	<tr>
		<td>Product Name : </td>
		<td><input type="text" name="name" class="form-control form-control-sm" required value="<?= $prev_data['name'];?>"></td>
	</tr>
	<tr>
		<td>Description : </td>
		<td><textarea class="form-control form-control-sm"><?= $prev_data['description'];?></textarea></td>
	</tr>
	<tr>
		<td>Price : </td>
		<td><input type="number" name="price" class="form-control form-control-sm" min="5" required value="<?= $prev_data['price'];?>"></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><button type="submit" name="updater" class="btn btn-success btn-block mb-3">Update</button></td>
	</tr>
</table>
</form>
	<?php include 'include/footer.php';?>
	</div>
</body>
</html>