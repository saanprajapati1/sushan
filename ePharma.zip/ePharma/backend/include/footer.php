<footer class="footer pt-0">
  <div class="row align-items-center justify-content-lg-between">
    <div class="col-lg-6">
      <div class="text-center text-lg-left text-muted" style="font-size: .875rem;">
        &copy; 2020 <a href="../about.php" class="font-weight-bold ml-1" target="_blank">ePharma Team</a>
      </div>
    </div>
    <div class="col-lg-6">
      <ul class="nav nav-footer justify-content-center justify-content-lg-end">
        <li class="nav-item">
          <a href="#" class="nav-link">EPharma Team</a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">Contact</a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">Objective</a>
        </li>
      </ul>
    </div>
  </div>
</footer>