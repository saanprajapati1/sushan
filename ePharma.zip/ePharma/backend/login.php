<?php
if(isset($_COOKIE["member_login"]))
{	
	if(empty($_SESSION))
		session_start();
	$_SESSION['username'] = $_COOKIE["member_login"];
	echo "<script>window.location='dashboard.php';</script>";
	exit;
}

if(isset($_POST['login']))
{
	$u = $_POST['username'];
	$p = $_POST['password'];

	$sql = "SELECT * FROM `admin` WHERE `email`='$u' AND `password`='$p';";
//echo $sql;
	require_once('DBConnect.php');
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0) 
	{
// echo "Login Successful";exit;
if(empty($_SESSION)) // if the session not yet started
session_start();
$_SESSION['username'] = $u;
$row = mysqli_fetch_assoc($result);
//echo "<pre>"; print_r($row);exit;
$_SESSION['u_id'] = $row['id'];
if(!empty($_POST["remember_me"])) {
	setcookie ("member_login",$_POST["username"],time()+(60 * 60)); /* expire in 1 hour */
} else {
	if(isset($_COOKIE["member_login"])) {
		setcookie ("member_login","");
	}
}
echo "<script>window.location='dashboard.php';</script>";		
exit; 
}else{
	echo "<script>alert('Username or Password Incorrect!');</script>";
	echo "<script>window.location='login.php';</script>";
	exit;
}
}
?>


<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
</head>
<body background="../images/map.jpeg"><br><br><br>
	<div class="jumbotron border border-primary rounded mx-auto" style="width: 50%;padding: 20px;opacity: .9;">
		<h3 align="center">ePharma Admin Access</h3><hr>
		<form method="POST">
			<div class="form-inline d-flex justify-content-center">
				<label for="username" class="m-3">Username : </label>
				<input type="text" name="username" class="form-control" required>
			</div>
			<div class="form-inline d-flex justify-content-center">
				<label for="password" class="m-3">Password : </label>
				<input type="password" name="password" class="form-control" required>
			</div>
			<div class="d-flex justify-content-center mt-3">
				<button type="submit" name="login" class="btn btn-outline-dark">Get Access</button>
			</div>
		</form>
	</div>
</body>
</html>