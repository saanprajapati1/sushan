<!DOCTYPE html>
<html>
	<head>
		<title>Log In</title>

	<body>

		<?php include 'include/navbar.php' ?>
		<div class="container" style="width: 60%;padding: 2rem;">
			<form class="jumbotron mt-5">
				<h4 align="left">Log In</h4><br>
				<div class="form-group">
					<label for="shopname">Your Pharmacy Shop Name :</label>
					<input type="text" class="form-control" name="shopname" required>
				</div>
				<div class="form-group">
					<label for="password">Your Password:</label>
					<input type="password" class="form-control" name="password" required>
				</div><br>
				<button type="submit" class="btn btn-outline-secondary" style="float:right;width: 25%;">Log In</button>
			</form>
			<p>Not registered yet ? <a href="registerform.php">Register with us</a> .</p>
		</div>
		<?php include 'include/footer.php' ?>
	</body>
</html>